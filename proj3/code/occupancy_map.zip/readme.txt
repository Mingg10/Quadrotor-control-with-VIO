This project was completed for the MEAM6200 course.

The core algorithm for reducing trajectory waypoint density is based on Ramer-Douglas-Peucher algorithm.
The idea of implementing RDP comes from one of the colleague.
However, there is no use or reference to others' work directly.
The implementation of the algorithm adapted based on the understanding of the paper:
The RDP path simplification method implemented in this project is inspired by the trajectory optimization approach discussed by Blauensteiner and Fahrnberger (2024).
DOI: 10.1007/978-3-031-60433-1_12

The idea of implementing adjustable velocity based on distance between points comes from one of the colleague.
However, there is no use or reference to other's code directly.

All other code was based solely on course materials, including lab handouts and lecture slides.
No external sources were used in completing this assignment.
